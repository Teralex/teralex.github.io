<?php

$q = array('res' => 'some');

echo json_encode($q);
